package nitCanteen;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Font;

import javax.swing.JComboBox;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTextArea;

public class Payment extends JInternalFrame {
	Connection connection=null;
	private JComboBox comboBox;
	private JTable table;
	private JTextArea textArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Payment frame = new Payment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void fillComboBox()
	{
		try 
		{
			String query="select * from attendance";
			PreparedStatement pst=connection.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			comboBox.addItem("Choose!!!!!");
			while(rs.next())
			{				
				comboBox.addItem(rs.getString("name"));
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 */
	public Payment() {
		connection=sqliteconnection.dbConnector();
		setTitle("Payment");
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		//setBounds(100, 100, 450, 300);
		setBounds(350, 33, 612, 661);
		getContentPane().setLayout(null);
		
		JLabel lblpayment = new JLabel("Employee Payment");
		lblpayment.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 30));
		lblpayment.setHorizontalAlignment(SwingConstants.CENTER);
		lblpayment.setBounds(10, 11, 576, 51);
		getContentPane().add(lblpayment);
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					
					String query="select * from attendance where name=?";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,(String)comboBox.getSelectedItem());
					ResultSet rs=pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rs));
					//pst.execute();
					pst.close();
					
					/*String query11="select total_attendance from attendance where name='"+(String)comboBox.getSelectedItem()+"'";
					PreparedStatement pst11=connection.prepareStatement(query11);
					
					ResultSet rs11=pst11.executeQuery();
					
					int s=Integer.parseInt(rs11.getString("total_attendance"));
					System.out.println(s);
						*/
					//System.out.println(rs.getString("name"));
					
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
			}
		});
		comboBox.setBounds(10, 128, 178, 42);
		getContentPane().add(comboBox);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(208, 92, 344, 239);
		getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnPayment = new JButton("Payment");
		btnPayment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query11="select perdaywages,total_attendance from attendance where name='"+(String)comboBox.getSelectedItem()+"'";
					PreparedStatement pst11=connection.prepareStatement(query11);
					
					ResultSet rs11=pst11.executeQuery();
					
					int s=Integer.parseInt(rs11.getString("total_attendance"));
					int r=Integer.parseInt(rs11.getString("perdaywages"));
					String total=String.valueOf(s*r);
					textArea.setText(""+total);
					
					System.out.println(s);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
		btnPayment.setFont(new Font("Times New Roman", Font.BOLD, 19));
		btnPayment.setBounds(100, 461, 159, 42);
		getContentPane().add(btnPayment);
		
		textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBounds(300, 473, 134, 22);
		getContentPane().add(textArea);
		fillComboBox();

	}
}
