package nitCanteen;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CashierPermanentItems extends JInternalFrame {
	Connection connection=null;
	private JTextField text_ItemName;
	private JTextField text_Price;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CashierPermanentItems frame = new CashierPermanentItems();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void fillComboBox()
	{
		try {
			String query="select * from permanent_item";
			PreparedStatement pst=connection.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			comboBox.addItem("Choose!!!!!");
			while(rs.next())
			{
				comboBox.addItem(rs.getString("item_name"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	/**
	 * Create the frame.
	 */
	public CashierPermanentItems() 
	{
		connection=sqliteconnection.dbConnector();
		setTitle("Cashier Permanent Items");
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		//setBounds(100, 100, 450, 300);
		setBounds(350, 33, 612, 661);
		getContentPane().setLayout(null);
		
		JLabel lblNewItem = new JLabel("New Item");
		lblNewItem.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 25));
		lblNewItem.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewItem.setBounds(10, 11, 576, 37);
		getContentPane().add(lblNewItem);
		
		JLabel lblItemName = new JLabel("Item Name");
		lblItemName.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblItemName.setBounds(91, 103, 102, 24);
		getContentPane().add(lblItemName);
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblPrice.setBounds(135, 152, 102, 24);
		getContentPane().add(lblPrice);
		
		text_ItemName = new JTextField();
		text_ItemName.setBounds(237, 96, 200, 29);
		getContentPane().add(text_ItemName);
		text_ItemName.setColumns(10);
		
		text_Price = new JTextField();
		text_Price.setBounds(237, 147, 200, 29);
		getContentPane().add(text_Price);
		text_Price.setColumns(10);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					String query="insert into permanent_item (item_name,price) values (?,?)";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,text_ItemName.getText());
					pst.setString(2,text_Price.getText());
					pst.execute();
					text_ItemName.setText("");
					text_Price.setText("");

					JOptionPane.showMessageDialog(null,"data saved");
					
					pst.close();
				
					//fillComboBox();
					//rs.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		btnAdd.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		btnAdd.setBounds(154, 415, 112, 37);
		getContentPane().add(btnAdd);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query="update permanent_item set item_name='"+text_ItemName.getText()+"' ,price='"+text_Price.getText()+"' where item_name='"+text_ItemName.getText()+"'";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.execute();
					text_ItemName.setText("");
					text_Price.setText("");
					JOptionPane.showMessageDialog(null,"data updated");
					pst.close();
					
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		});
		btnUpdate.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		btnUpdate.setBounds(338, 416, 112, 37);
		getContentPane().add(btnUpdate);
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query="select * from permanent_item where item_name=?";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,(String)comboBox.getSelectedItem());
					ResultSet rs=pst.executeQuery();
					while(rs.next())
					{
						text_ItemName.setText(rs.getString("item_name"));
						text_Price.setText(rs.getString("price"));
					}
					//pst.execute();
					pst.close();
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		comboBox.setBounds(288, 257, 162, 37);
		getContentPane().add(comboBox);
		
		JLabel lblSelectItemname = new JLabel("Select ItemName");
		lblSelectItemname.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblSelectItemname.setBounds(140, 270, 114, 24);
		getContentPane().add(lblSelectItemname);
		fillComboBox();
	}

}
