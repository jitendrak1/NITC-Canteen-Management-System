package nitCanteen;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.swing.JTextField;
import javax.swing.JButton;

//import mainCanteen.sqliteconnection;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EmployeeRegistration extends JInternalFrame
{
	private JTextField text_EmployeeID;
	private JTextField text_AdharCardNo;
	private JTextField text_Name;
	private JTextField text_Fname;
	private JTextField textDOB;
	private JTextField textAddress;
	private JTextField text_Mobile;
	private JTextField text_PerDayWages;
	Connection connection=null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try 
				{
					EmployeeRegistration frame = new EmployeeRegistration();
					frame.setVisible(true);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EmployeeRegistration() 
	{
		connection=sqliteconnection.dbConnector();
		getContentPane().setFont(new Font("Times New Roman", Font.PLAIN, 15));
		setTitle("Employee Registration");
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		//setBounds(100, 100, 450, 300);
		setBounds(350, 33, 648, 661);
		getContentPane().setLayout(null);
		
		JLabel lblEmployeeRegistration = new JLabel("Employee Registration");
		lblEmployeeRegistration.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 23));
		lblEmployeeRegistration.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmployeeRegistration.setBounds(0, 0, 632, 35);
		getContentPane().add(lblEmployeeRegistration);
		
		JLabel lblEmployeeID = new JLabel("Employee ID");
		lblEmployeeID.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblEmployeeID.setBounds(86, 46, 124, 19);
		getContentPane().add(lblEmployeeID);
		
		JLabel lblAdharCARDNO = new JLabel("Adhar Card NO.");
		lblAdharCARDNO.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblAdharCARDNO.setBounds(86, 88, 105, 14);
		getContentPane().add(lblAdharCARDNO);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblName.setBounds(86, 119, 63, 19);
		getContentPane().add(lblName);
		
		JLabel lblFatherName = new JLabel("Father Name");
		lblFatherName.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblFatherName.setBounds(86, 149, 82, 14);
		getContentPane().add(lblFatherName);
		
		JLabel lblDob = new JLabel("D.O.B.");
		lblDob.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblDob.setBounds(86, 184, 63, 14);
		getContentPane().add(lblDob);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblAddress.setBounds(86, 219, 80, 14);
		getContentPane().add(lblAddress);
		
		JLabel lblMobile = new JLabel("Mobile");
		lblMobile.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblMobile.setBounds(86, 252, 56, 14);
		getContentPane().add(lblMobile);
		
		JLabel lblPerDayWages = new JLabel("Per Day Wages");
		lblPerDayWages.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblPerDayWages.setBounds(86, 290, 105, 14);
		getContentPane().add(lblPerDayWages);
		
		text_EmployeeID = new JTextField();
		text_EmployeeID.setBounds(257, 47, 184, 19);
		getContentPane().add(text_EmployeeID);
		text_EmployeeID.setColumns(10);
		
		text_AdharCardNo = new JTextField();
		text_AdharCardNo.setBounds(257, 86, 184, 19);
		getContentPane().add(text_AdharCardNo);
		text_AdharCardNo.setColumns(10);
		
		text_Name = new JTextField();
		text_Name.setBounds(257, 119, 184, 19);
		getContentPane().add(text_Name);
		text_Name.setColumns(10);
		
		text_Fname = new JTextField();
		text_Fname.setBounds(257, 149, 184, 19);
		getContentPane().add(text_Fname);
		text_Fname.setColumns(10);
		
		textDOB = new JTextField();
		textDOB.setBounds(257, 182, 184, 19);
		getContentPane().add(textDOB);
		textDOB.setColumns(10);
		
		textAddress = new JTextField();
		textAddress.setBounds(257, 217, 184, 19);
		getContentPane().add(textAddress);
		textAddress.setColumns(10);
		
		text_Mobile = new JTextField();
		text_Mobile.setBounds(257, 250, 184, 19);
		getContentPane().add(text_Mobile);
		text_Mobile.setColumns(10);
		
		text_PerDayWages = new JTextField();
		text_PerDayWages.setBounds(257, 288, 184, 19);
		getContentPane().add(text_PerDayWages);
		text_PerDayWages.setColumns(10);
		
		JButton btnSignUp = new JButton("Add");
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					String query="insert into employeereg (empid,Adharno,name,fname,dob,address,mobile,perdaywages) values (?,?,?,?,?,?,?,?)";
					String query1="insert into attendance (name,perdaywages) values (?,?)";
					PreparedStatement pst=connection.prepareStatement(query);
					PreparedStatement pst1=connection.prepareStatement(query1);
					pst.setString(1,text_EmployeeID.getText());
					pst.setString(2,text_AdharCardNo.getText());
					pst.setString(3,text_Name.getText());
					pst.setString(4,text_Fname.getText());
					pst.setString(5,textDOB.getText());
					pst.setString(6,textAddress.getText());
					pst.setString(7,text_Mobile.getText());
					pst.setString(8,text_PerDayWages .getText());
					pst.execute();
					JOptionPane.showMessageDialog(null,"data saved");
					pst.close();
					
					pst1.setString(1,text_Name.getText());
					pst1.setString(2,text_PerDayWages .getText());
					pst1.execute();
					JOptionPane.showMessageDialog(null,"data saved");
					pst1.close();
				}
				catch(Exception ex){
					ex.printStackTrace();
				}
			}
		});
		btnSignUp.setFont(new Font("Times New Roman", Font.BOLD, 22));
		btnSignUp.setBounds(130, 351, 112, 35);
		getContentPane().add(btnSignUp);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				text_EmployeeID.setText("");
				text_AdharCardNo.setText("");
				text_Name.setText("");
				text_Fname.setText("");
				textDOB.setText("");
				textAddress.setText("");
				text_Mobile.setText("");
				text_PerDayWages.setText("");
				
			}
		});
		btnReset.setFont(new Font("Times New Roman", Font.BOLD, 22));
		btnReset.setBounds(356, 351, 112, 35);
		getContentPane().add(btnReset);
	}
}
