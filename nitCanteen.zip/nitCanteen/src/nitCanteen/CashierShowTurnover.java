package nitCanteen;

import java.awt.EventQueue;
import java.sql.Connection;

import javax.swing.JInternalFrame;

public class CashierShowTurnover extends JInternalFrame 
{
	Connection connection=null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					CashierShowTurnover frame = new CashierShowTurnover();
					frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CashierShowTurnover() 
	{
		connection=sqliteconnection.dbConnector();
		setTitle("Cashier Show Turnover");
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		//setBounds(100, 100, 450, 300);
		setBounds(350, 33, 612, 661);

	}

}
