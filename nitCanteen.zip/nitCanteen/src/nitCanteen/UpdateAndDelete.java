package nitCanteen;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ButtonGroup;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JComboBox;
import javax.swing.JRadioButton;

public class UpdateAndDelete extends JInternalFrame {
	Connection connection=null;
	private JTextField textField;
	private JTextField text_EmployeeID;
	private JTextField text_AdharCardNo;
	private JTextField text_Name;
	private JTextField text_Fname;
	private JTextField textDOB;
	private JTextField textAddress;
	private JTextField text_Mobile;
	private JTextField text_PerDayWages;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdateAndDelete frame = new UpdateAndDelete();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void fillComboBox()
	{
		try 
		{
			String query="select * from employeereg";
			PreparedStatement pst=connection.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			comboBox.addItem("Choose!!!!!");
			while(rs.next())
			{
				
				comboBox.addItem(rs.getString("name"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 */
	public UpdateAndDelete() {
		connection=sqliteconnection.dbConnector();
		setTitle("Update And Delete");
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		
		//setBounds(100, 100, 450, 300);
		setBounds(350, 33, 612, 661);
		getContentPane().setLayout(null);
		
		JLabel lblEmployeeID = new JLabel("Employee ID");
		lblEmployeeID.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblEmployeeID.setBounds(81, 74, 114, 24);
		getContentPane().add(lblEmployeeID);
		
		JLabel lblAdharCARDNO = new JLabel("Adhar Card NO");
		lblAdharCARDNO.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblAdharCARDNO.setBounds(81, 120, 126, 24);
		getContentPane().add(lblAdharCARDNO);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblName.setBounds(81, 163, 68, 24);
		getContentPane().add(lblName);
		
		JLabel lblFatherName = new JLabel("Father Name");
		lblFatherName.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblFatherName.setBounds(81, 209, 114, 24);
		getContentPane().add(lblFatherName);
		
		JLabel lblDob = new JLabel("DOB");
		lblDob.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblDob.setBounds(81, 254, 68, 24);
		getContentPane().add(lblDob);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblAddress.setBounds(81, 299, 78, 24);
		getContentPane().add(lblAddress);
		
		JLabel lblMobile = new JLabel("Mobile");
		lblMobile.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblMobile.setBounds(81, 342, 68, 24);
		getContentPane().add(lblMobile);
		
		JLabel lblPerDayWages = new JLabel("Per Day Wages");
		lblPerDayWages.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblPerDayWages.setBounds(81, 391, 126, 24);
		getContentPane().add(lblPerDayWages);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					
					String query="update employeereg set empid='"+text_EmployeeID.getText()+"', Adharno='"+text_AdharCardNo.getText()+"', name='"+text_Name.getText()+"' , fname='"+text_Fname.getText()+"' ,   dob='"+textDOB.getText()+"',address='"+textAddress.getText()+"', mobile='"+text_Mobile.getText()+"' , perdaywages='"+text_PerDayWages.getText()+"'  where empid='"+text_EmployeeID.getText()+"'";
					String query2="update attendance set  name='"+text_Name.getText()+"',perdaywages='"+text_PerDayWages.getText()+"' where  name='"+text_Name.getText()+"'";
					text_EmployeeID.setText("");
					text_AdharCardNo.setText("");
					text_Name.setText("");
					text_Fname.setText("");
					textDOB.setText("");
					textAddress.setText("");
					text_Mobile.setText("");
					text_PerDayWages.setText("");

					PreparedStatement pst=connection.prepareStatement(query);
					pst.execute();
					JOptionPane.showMessageDialog(null,"data updated");
					pst.close();
					
					PreparedStatement pst1=connection.prepareStatement(query2);
					pst1.execute();
					JOptionPane.showMessageDialog(null,"data updated attendance");
					pst1.close();
					
					
				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();
				}
	
			}
		});
		btnUpdate.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnUpdate.setBounds(46, 458, 161, 44);
		getContentPane().add(btnUpdate);
		btnUpdate.setVisible(false);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				text_EmployeeID.setText("");
				text_AdharCardNo.setText("");
				text_Name.setText("");
				text_Fname.setText("");
				textDOB.setText("");
				textAddress.setText("");
				text_Mobile.setText("");
				text_PerDayWages.setText("");
			}
		});
		btnReset.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnReset.setBounds(383, 458, 172, 44);
		getContentPane().add(btnReset);
		btnReset.setVisible(false);
		
		text_EmployeeID = new JTextField();
		text_EmployeeID.setBounds(333, 77, 190, 24);
		getContentPane().add(text_EmployeeID);
		text_EmployeeID.setColumns(10);
		
		text_AdharCardNo = new JTextField();
		text_AdharCardNo.setBounds(333, 112, 190, 29);
		getContentPane().add(text_AdharCardNo);
		text_AdharCardNo.setColumns(10);
		
		text_Name = new JTextField();
		text_Name.setBounds(333, 156, 190, 29);
		getContentPane().add(text_Name);
		text_Name.setColumns(10);
		
		text_Fname = new JTextField();
		text_Fname.setBounds(333, 204, 190, 29);
		getContentPane().add(text_Fname);
		text_Fname.setColumns(10);
		
		textDOB = new JTextField();
		textDOB.setBounds(333, 246, 190, 24);
		getContentPane().add(textDOB);
		textDOB.setColumns(10);
		
		textAddress = new JTextField();
		textAddress.setBounds(333, 285, 190, 29);
		getContentPane().add(textAddress);
		textAddress.setColumns(10);
		
		text_Mobile = new JTextField();
		text_Mobile.setBounds(333, 334, 190, 24);
		getContentPane().add(text_Mobile);
		text_Mobile.setColumns(10);
		
		text_PerDayWages = new JTextField();
		text_PerDayWages.setBounds(333, 375, 190, 24);
		getContentPane().add(text_PerDayWages);
		text_PerDayWages.setColumns(10);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try 
				{
					String query="delete from employeereg where name='"+text_Name.getText()+"'";
					String query1="delete from attendance where name='"+text_Name.getText()+"'";
					text_EmployeeID.setText("");
					text_AdharCardNo.setText("");
					text_Name.setText("");
					text_Fname.setText("");
					textDOB.setText("");
					textAddress.setText("");
					text_Mobile.setText("");
					text_PerDayWages.setText("");
					PreparedStatement pst=connection.prepareStatement(query);
					pst.execute();
					JOptionPane.showMessageDialog(null,"data deleted");
					pst.close();
					
					PreparedStatement pst2=connection.prepareStatement(query1);
					pst2.execute();
					JOptionPane.showMessageDialog(null,"data deleted");
					pst2.close();					
				} 
				catch (Exception e3)
				{
					e3.printStackTrace();
				}
			}
		});
		btnDelete.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnDelete.setBounds(226, 546, 161, 44);
		getContentPane().add(btnDelete);
		btnDelete.setVisible(false);
		
	    comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				
				try 
				{
					String query="select * from employeereg where name=?";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,(String)comboBox.getSelectedItem());
					ResultSet rs=pst.executeQuery();
					while(rs.next())
					{
						text_EmployeeID.setText(rs.getString("empid"));
						text_AdharCardNo.setText(rs.getString("Adharno"));
						text_Name.setText(rs.getString("name"));
						text_Fname.setText(rs.getString("fname"));
						textDOB.setText(rs.getString("dob"));
						textAddress.setText(rs.getString("address"));
						text_Mobile.setText(rs.getString("mobile"));
						text_PerDayWages.setText(rs.getString("perdaywages"));
					}
					//pst.execute();
					pst.close();
					
				} 
				catch (Exception e1)
				{
					e1.printStackTrace();
				}
			}
		});
		comboBox.setBounds(383, 21, 172, 29);
		getContentPane().add(comboBox);
		
		JLabel lblEmployeeName = new JLabel("Employee Name :");
		lblEmployeeName.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblEmployeeName.setBounds(225, 21, 148, 22);
		getContentPane().add(lblEmployeeName);
		
		JRadioButton rdbtnDelete = new JRadioButton("Delete");
		rdbtnDelete.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				btnUpdate.setVisible(false);
				btnDelete.setVisible(true);
				btnReset.setVisible(true);
			}
		});
		rdbtnDelete.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		rdbtnDelete.setBounds(7, 10, 68, 44);
		getContentPane().add(rdbtnDelete);
		
		JRadioButton rdbtnUpdate = new JRadioButton("Update");
		rdbtnUpdate.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				btnUpdate.setVisible(true);
				btnDelete.setVisible(false);
				btnReset.setVisible(true);
			}
		});
		rdbtnUpdate.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		rdbtnUpdate.setBounds(81, 22, 78, 24);
		getContentPane().add(rdbtnUpdate);
		ButtonGroup g=new ButtonGroup();
		g.add(rdbtnDelete);
		g.add(rdbtnUpdate);
		fillComboBox();
		
	}
}
