package nitCanteen;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.JButton;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

public class NewOrder extends JInternalFrame 
{
	Connection connection=null;
	private JLabel lblNewLabel;
	private JTextField text_order;
	private JLabel lbl_OrderNo;
	private JTextField text_Name;
	private JTextField text_Price;
	private JTextField text_Quantity;
	private JTable table;
	private JTable table_1;
	private JComboBox comboBox;
	private JTextArea textPrint_total;
	
	int totall;
	String date;
	public static String Order;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					NewOrder frame = new NewOrder();
					frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public void refreshTable()
	{
		try
		{
			String query="select * from temporary_items";
			PreparedStatement pst=connection.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void fillComboBox()
	{
		try {
			String query="select * from permanent_item";
			PreparedStatement pst=connection.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			comboBox.addItem("Choose!!!!!");
			while(rs.next())
			{
				comboBox.addItem(rs.getString("item_name"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void clock()
	{
		Thread clock=new Thread()
		{
			public void run()
			{
				try{
					for(;;){
					Calendar cal=new GregorianCalendar();
					int day=cal.get(Calendar.DAY_OF_MONTH);
					int month=cal.get(Calendar.MONTH);
					int year=cal.get(Calendar.YEAR);
					
					int second=cal.get(Calendar.SECOND);
					int minute=cal.get(Calendar.MINUTE);
					int hour=cal.get(Calendar.HOUR);
					
					lblNewLabel.setText("Time "+hour+":"+minute+":"+second+"   Date "+year+"/"+(month+1)+"/"+day);
					
				    date=day+"/"+month+"/"+year;
					//System.out.println(date);
										
					sleep(1000);
					}
					
				}catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			
		};
		clock.start();
		
		
	}
	 	
	public NewOrder()
	{
		Order="1";
		connection=sqliteconnection.dbConnector();
		setTitle("New Order");
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		//setBounds(100, 100, 681, 477);
		setBounds(350, 33, 766, 655);
		getContentPane().setLayout(null);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(387, 11, 200, 50);
		getContentPane().add(lblNewLabel);
		
		lbl_OrderNo = new JLabel("Order No :");
		lbl_OrderNo.setBounds(23, 11, 90, 31);
		lbl_OrderNo.setFont(new Font("Times New Roman", Font.ITALIC, 18));
		getContentPane().add(lbl_OrderNo);
		
		text_order = new JTextField();
		text_order.setEditable(false);
		text_order.setBounds(120, 16, 75, 25);
		getContentPane().add(text_order);
		text_order.setColumns(10);
		text_order.setText(Order);
		
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				try {
					String query="select * from permanent_item where item_name=?";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,(String)comboBox.getSelectedItem());
					ResultSet rs=pst.executeQuery();
					text_Name.setText("");
					text_Quantity.setText("");
					text_Price.setText("");
					while(rs.next())
					{
						text_Name.setText(rs.getString("item_name"));
						//text_Quantity.setText(rs.getString("item_quantity"));
						text_Price.setText(rs.getString("price"));
					}
					//pst.execute();
					pst.close();
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		comboBox.setBounds(157, 106, 140, 20);
		getContentPane().add(comboBox);
		
		JLabel lblItemName = new JLabel("Item Name");
		lblItemName.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblItemName.setBounds(34, 106, 113, 17);
		getContentPane().add(lblItemName);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblName.setBounds(34, 180, 69, 20);
		getContentPane().add(lblName);
		
		text_Name = new JTextField();
		text_Name.setBounds(157, 180, 140, 22);
		getContentPane().add(text_Name);
		text_Name.setColumns(10);
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblPrice.setBounds(34, 228, 69, 25);
		getContentPane().add(lblPrice);
		
		text_Price = new JTextField();
		text_Price.setBounds(154, 228, 143, 24);
		getContentPane().add(text_Price);
		text_Price.setColumns(10);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblQuantity.setBounds(34, 281, 99, 25);
		getContentPane().add(lblQuantity);
		
		text_Quantity = new JTextField();
		text_Quantity.setBounds(154, 285, 143, 20);
		getContentPane().add(text_Quantity);
		text_Quantity.setColumns(10);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0)
			{
				int a=0,b=0;
				try 
				{
					a=Integer.parseInt(text_Price.getText());					
					b=Integer.parseInt(text_Quantity.getText());
					
					 String query11="select perday_quantity from perday_item where item_name='"+(String)comboBox.getSelectedItem()+"'";
					 PreparedStatement pst11=connection.prepareStatement(query11);
						
						ResultSet rs11=pst11.executeQuery();
						
						
						int s=Integer.parseInt(rs11.getString("perday_quantity"));
						int newquantity=s-b;
						//System.out.println(newquantity);
				   if(s>b)
					{
					
					String query="insert into temporary_items (item_name,price,quantity,total) values (?,?,?,?)";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,text_Name.getText());
					pst.setString(2,text_Price.getText());
					pst.setString(3,text_Quantity.getText());
					
					
					String total=String.valueOf(a*b);
					pst.setString(4,total);
					
					pst.execute();
					text_Name.setText("");
					text_Price.setText("");
					text_Quantity.setText("");
					JOptionPane.showMessageDialog(null,"data saved");
				    pst.close();
				    
				    //String select_item=(String)comboBox.getSelectedItem();
				    
				  
					String q1="update perday_item set perday_quantity='"+newquantity+"' where item_name='"+(String)comboBox.getSelectedItem()+"'";
					PreparedStatement pst1=connection.prepareStatement(q1);
					
					pst1.execute();
					JOptionPane.showMessageDialog(null,"data updated perday item");
					pst1.close();
				   }
				   else
				   {
					   JOptionPane.showMessageDialog(null,"Remaining Dishes Quntity :"+s);  
				   }					
				} 
				catch (Exception ex) 
				{
					ex.printStackTrace();
				}
				refreshTable();
			}
		});
		btnAdd.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnAdd.setBounds(58, 358, 99, 31);
		getContentPane().add(btnAdd);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				text_Name.setText("");
				text_Quantity.setText("");
				text_Price.setText("");
			}
		});
		btnReset.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnReset.setBounds(208, 358, 99, 29);
		getContentPane().add(btnReset);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				int a=0,b=0;				
				try 
				{		
					a=Integer.parseInt(text_Price.getText());					
					b=Integer.parseInt(text_Quantity.getText());
					
					//select total item from perday item table
					 String query11="select perday_quantity from perday_item where item_name='"+(String)comboBox.getSelectedItem()+"'";
					 PreparedStatement pst11=connection.prepareStatement(query11);
					 ResultSet rs11=pst11.executeQuery();
					 int p=Integer.parseInt(rs11.getString("perday_quantity"));
					 
					 //select previoue quantity from temporary table
					 
					 String query12="select quantity from temporary_items where item_name='"+(String)comboBox.getSelectedItem()+"'";
					 PreparedStatement pst12=connection.prepareStatement(query12);
					 ResultSet rs12=pst12.executeQuery();
					 int s1=Integer.parseInt(rs12.getString("quantity"));
					
					 System.out.println("==value of s "+ p+" value of s1 "+s1+"value of b "+b);
					
					 if(p>b)
					 {
						 if(s1<b)
						 {
							 p=(p+s1)-b;
						 }
						 else
						 {
							 p=(p+s1)-b;
						 }
						 System.out.println("**value of s "+p+" value of s1 "+s1+" value of b "+b);
						 
					String total=String.valueOf(a*b);
					
					System.out.println(" new total :"+total);
					
					String query="update temporary_items set item_name='"+text_Name.getText()+"' , quantity='"+text_Quantity.getText()+"',price='"+text_Price.getText()+"',total='"+total +"' where item_name='"+text_Name.getText()+"'";
					PreparedStatement pst=connection.prepareStatement(query);
					
					pst.execute();
					text_Name.setText("");
					text_Quantity.setText("");
					text_Price.setText("");
					JOptionPane.showMessageDialog(null,"data updated");
					pst.close();
					
					//update perday item Quantity
					
					String q1="update perday_item set perday_quantity='"+p+"' where item_name='"+(String)comboBox.getSelectedItem()+"'";
					PreparedStatement pst1=connection.prepareStatement(q1);
					
					pst1.execute();
					JOptionPane.showMessageDialog(null,"data updated perday item");
					pst1.close();
					
					 }
					 else
					 {
						 JOptionPane.showMessageDialog(null,"Remaining Dishes Quntity :"+p);  
					 }
					
					
				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();
				}
				refreshTable();
			}
		});
		btnUpdate.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnUpdate.setBounds(58, 426, 99, 31);
		getContentPane().add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				try {
					
					 String query12="select quantity from temporary_items where item_name='"+(String)comboBox.getSelectedItem()+"'";
					 PreparedStatement pst12=connection.prepareStatement(query12);
					 ResultSet rs12=pst12.executeQuery();
					 int s1=Integer.parseInt(rs12.getString("quantity"));
					 
					 String query11="select perday_quantity from perday_item where item_name='"+(String)comboBox.getSelectedItem()+"'";
					 PreparedStatement pst11=connection.prepareStatement(query11);
					 ResultSet rs11=pst11.executeQuery();
					 int p=Integer.parseInt(rs11.getString("perday_quantity"));
					  
					 p=p+s1; 
					 
					 
					 String q1="update perday_item set perday_quantity='"+p+"' where item_name='"+(String)comboBox.getSelectedItem()+"'";
						PreparedStatement pst1=connection.prepareStatement(q1);
						
						pst1.execute();
						JOptionPane.showMessageDialog(null,"data updated perday item");
						pst1.close();
					
					String query="delete from temporary_items where item_name='"+text_Name.getText()+"'";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.execute();
					text_Name.setText("");
					text_Quantity.setText("");
					text_Price.setText("");
					JOptionPane.showMessageDialog(null,"data deleted");
					pst.close();
					
					
					
					
					
				} catch (Exception e3) {
					e3.printStackTrace();
				}
				refreshTable();
			}
		});
		btnDelete.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnDelete.setBounds(208, 426, 99, 29);
		getContentPane().add(btnDelete);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(387, 86, 338, 406);
		getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					int row=table.getSelectedRow();
					String name_=(table.getModel().getValueAt(row, 0)).toString();
					
					String query="select * from temporary_items where item_name='"+name_+"'";
					PreparedStatement pst=connection.prepareStatement(query);
					
					ResultSet rs=pst.executeQuery();
					while(rs.next())
					{
						text_Name.setText(rs.getString("item_name"));
						text_Quantity.setText(rs.getString("quantity"));
						text_Price.setText(rs.getString("price"));
											
					}
					//pst.execute();
					pst.close();
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
			}
		});
		scrollPane.setViewportView(table);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(23, 86, 336, 407);
		getContentPane().add(scrollPane_1);
		
		table_1 = new JTable();
		scrollPane_1.setViewportView(table_1);
		
		JButton btnTotal = new JButton("Total");
		btnTotal.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				try 
				{				
					totall=0;
					String query="select total from temporary_items";
					PreparedStatement pst=connection.prepareStatement(query);
					
					ResultSet rs=pst.executeQuery();
					while(rs.next())
					{
						int s=Integer.parseInt(rs.getString("total"));
					    totall=totall+s;
					    textPrint_total.setText(""+totall);
					    
					}
					//pst.execute();
					pst.close();
					
				} 
				catch (Exception e1)
				{
					e1.printStackTrace();
				}
			}
		});
		btnTotal.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnTotal.setBounds(95, 540, 89, 23);
		getContentPane().add(btnTotal);
		
		textPrint_total = new JTextArea();
		textPrint_total.setEditable(false);
		textPrint_total.setBounds(208, 542, 83, 21);
		getContentPane().add(textPrint_total);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{						
				//System.out.println("order no"+Order+"date"+date+"order total "+totall);
				
				try 
				{
					String query="insert into billing (order_no,date,billing_total) values (?,?,?)";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,Order);
					pst.setString(2,date);
					pst.setString(3,""+totall);						
					pst.execute();					
					JOptionPane.showMessageDialog(null,"data saved");					
					pst.close();
					
					int order_total=Integer.parseInt(Order);
					order_total=order_total+1;
					String ss = ""+order_total;
					Order=ss;
					text_order.setText(""+order_total);	
				    
					String query1="delete from temporary_items ";
					PreparedStatement pst1=connection.prepareStatement(query1);
					pst1.execute();
					
					JOptionPane.showMessageDialog(null,"data deleted temporary table");
					pst1.close();
					
					DefaultTableModel dm = (DefaultTableModel)table.getModel();
					while(dm.getRowCount() > 0)
					{
					    dm.removeRow(0);
					}
					
					textPrint_total.setText("");
									
				} 
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
				
			}
		});
		btnPrint.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnPrint.setBounds(521, 540, 99, 26);
		getContentPane().add(btnPrint);
		clock();
		fillComboBox();
		refreshTable();

	}
}
