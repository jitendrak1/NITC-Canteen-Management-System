package nitCanteen;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ButtonGroup;
import javax.swing.JInternalFrame;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JPanel;

public class CashierExpenditureUpdate extends JInternalFrame {
	Connection connection=null;
	private JTextField text_ItemName;
	private JTextField text_ItemQuantity;
	private JTextField text_Price;
	private JComboBox comboBox;
	private JButton btnAdd;
	private JButton btnUpdate;
	private JButton btnDelete;
	private JButton btnReset;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CashierExpenditureUpdate frame = new CashierExpenditureUpdate();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void fillComboBox()
	{
		try {
			String query="select * from expenditure";
			PreparedStatement pst=connection.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			comboBox.addItem("Choose!!!!!");
			while(rs.next())
			{
				comboBox.addItem(rs.getString("item_name"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	/**
	 * Create the frame.
	 */
	public CashierExpenditureUpdate() {
		getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 11));
		connection=sqliteconnection.dbConnector();
		setTitle("Cashier Expenditure Update");
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		//setBounds(100, 100, 450, 300);
		setBounds(350, 33, 612, 661);
		getContentPane().setLayout(null);
		
		JRadioButton rdbtnNewItem = new JRadioButton("New Item");
		rdbtnNewItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				btnAdd.setVisible(true);
				btnReset.setVisible(true);
				btnUpdate.setVisible(false);
				btnDelete.setVisible(false);
				comboBox.setVisible(false);
				text_ItemName.setText("");
				text_ItemQuantity.setText("");
				text_Price.setText("");

			}
		});
		rdbtnNewItem.setFont(new Font("Times New Roman", Font.BOLD, 20));
		rdbtnNewItem.setBounds(50, 79, 109, 23);
		getContentPane().add(rdbtnNewItem);
		
		JRadioButton rdbtnUpdate = new JRadioButton("Update");
		rdbtnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnUpdate.setVisible(true);
				btnReset.setVisible(true);
				comboBox.setVisible(true);
				btnDelete.setVisible(false);
				btnAdd.setVisible(false);
				text_ItemName.setText("");
				text_ItemQuantity.setText("");
				text_Price.setText("");
			}
		});
		rdbtnUpdate.setFont(new Font("Times New Roman", Font.BOLD, 20));
		rdbtnUpdate.setBounds(182, 79, 109, 23);
		getContentPane().add(rdbtnUpdate);
		
		JRadioButton rdbtnDelete = new JRadioButton("Delete");
		rdbtnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				btnDelete.setVisible(true);
				btnReset.setVisible(true);
				comboBox.setVisible(true);
				btnAdd.setVisible(false);
				btnUpdate.setVisible(false);
				text_ItemName.setText("");
				text_ItemQuantity.setText("");
				text_Price.setText("");
			}
		});
		rdbtnDelete.setFont(new Font("Times New Roman", Font.BOLD, 20));
		rdbtnDelete.setBounds(293, 79, 109, 23);
		getContentPane().add(rdbtnDelete);
		
		
		ButtonGroup g=new ButtonGroup();
		g.add(rdbtnDelete);
		g.add(rdbtnUpdate);
		g.add(rdbtnNewItem);
		JLabel lblItemName = new JLabel("Item Name :");
		lblItemName.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblItemName.setBounds(89, 168, 116, 23);
		getContentPane().add(lblItemName);
		
		
		text_ItemName = new JTextField();
		text_ItemName.setBounds(224, 168, 183, 24);
		getContentPane().add(text_ItemName);
		text_ItemName.setColumns(10);
		
		JLabel lblItemQuantity = new JLabel("Item Quantity :");
		lblItemQuantity.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblItemQuantity.setBounds(89, 235, 116, 23);
		getContentPane().add(lblItemQuantity);
		
		text_ItemQuantity = new JTextField();
		text_ItemQuantity.setBounds(223, 235, 184, 24);
		getContentPane().add(text_ItemQuantity);
		text_ItemQuantity.setColumns(10);
		
		JLabel lblPrice = new JLabel("Price :");
		lblPrice.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblPrice.setBounds(89, 302, 85, 23);
		getContentPane().add(lblPrice);
		
		text_Price = new JTextField();
		text_Price.setBounds(223, 302, 184, 24);
		getContentPane().add(text_Price);
		text_Price.setColumns(10);
		
		btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				int a=0,b=0;
				try 
				{
					String query="insert into expenditure (item_name,item_quantity,price,total_price) values (?,?,?,?)";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,text_ItemName.getText());
					pst.setString(2,text_ItemQuantity.getText());
					pst.setString(3,text_Price.getText());
					
					a=Integer.parseInt(text_Price.getText());					
					b=Integer.parseInt(text_ItemQuantity.getText());
					
					//System.out.println(a+""+b);
					//System.out.println("multy is ;"+a*b);
					
					String total=String.valueOf(a*b);
					pst.setString(4,total);
					
					pst.execute();
					text_ItemName.setText("");
					text_ItemQuantity.setText("");
					text_Price.setText("");
					JOptionPane.showMessageDialog(null,"data saved");
					
					pst.close();
				
					//fillComboBox();
					//rs.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		btnAdd.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnAdd.setBounds(38, 391, 136, 39);
		getContentPane().add(btnAdd);
		btnAdd.setVisible(false);
		
		btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				int a=0,b=0;
				try {
					a=Integer.parseInt(text_Price.getText());					
					b=Integer.parseInt(text_ItemQuantity.getText());
					
					String total=String.valueOf(a*b);
					
					System.out.println(" new total :"+total);
					String query="update expenditure set item_name='"+text_ItemName.getText()+"' , item_quantity='"+text_ItemQuantity.getText()+"',price='"+text_Price.getText()+"',total_price='"+total +"' where item_name='"+text_ItemName.getText()+"'";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.execute();
					text_ItemName.setText("");
					text_ItemQuantity.setText("");
					text_Price.setText("");
					JOptionPane.showMessageDialog(null,"data updated");
					pst.close();
					
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		});
		
		btnUpdate.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnUpdate.setBounds(139, 392, 136, 37);
		getContentPane().add(btnUpdate);
		btnUpdate.setVisible(false);
		
		btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query="delete from expenditure where item_name='"+text_ItemName.getText()+"'";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.execute();
					text_ItemName.setText("");
					text_ItemQuantity.setText("");
					text_Price.setText("");
					JOptionPane.showMessageDialog(null,"data deleted");
					pst.close();
					
					
					
				} catch (Exception e3) {
					e3.printStackTrace();
				}
			}
		});
		btnDelete.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnDelete.setBounds(240, 391, 136, 39);
		getContentPane().add(btnDelete);
		btnDelete.setVisible(false);
		
		btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				text_ItemName.setText("");
				text_ItemQuantity.setText("");
				text_Price.setText("");
			}
		});
		btnReset.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnReset.setBounds(431, 391, 121, 39);
		getContentPane().add(btnReset);
		btnReset.setVisible(false);
		
		JLabel lblDate = new JLabel("Date :");
		lblDate.setFont(new Font("Times New Roman", Font.ITALIC, 20));
		lblDate.setBounds(324, 31, 59, 18);
		getContentPane().add(lblDate);
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try {
					String query="select * from expenditure where item_name=?";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,(String)comboBox.getSelectedItem());
					ResultSet rs=pst.executeQuery();
					while(rs.next())
					{
						text_ItemName.setText(rs.getString("item_name"));
						text_ItemQuantity.setText(rs.getString("item_quantity"));
						text_Price.setText(rs.getString("price"));
					}
					//pst.execute();
					pst.close();
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		comboBox.setBounds(431, 164, 155, 27);
		getContentPane().add(comboBox);		
		
		comboBox.setVisible(false);
		fillComboBox();

	}
}
