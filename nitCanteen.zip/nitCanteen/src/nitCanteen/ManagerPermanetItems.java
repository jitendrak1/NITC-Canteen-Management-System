package nitCanteen;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ManagerPermanetItems extends JInternalFrame {
	Connection connection=null;
	private JTextField text_ItemName;
	private JTextField text_Price;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManagerPermanetItems frame = new ManagerPermanetItems();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void fillComboBox()
	{
		try {
			String query="select * from permanent_item";
			PreparedStatement pst=connection.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			comboBox.addItem("Choose!!!!!");
			while(rs.next())
			{
				comboBox.addItem(rs.getString("item_name"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 */
	public ManagerPermanetItems() {
		connection=sqliteconnection.dbConnector();
		setTitle("Manager Permanent Items");
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		//setBounds(100, 100, 450, 300);
		setBounds(350, 33, 612, 661);
		getContentPane().setLayout(null);
		
		JLabel lblNewItem = new JLabel("New Item");
		lblNewItem.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewItem.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 30));
		lblNewItem.setBounds(10, 34, 576, 29);
		getContentPane().add(lblNewItem);
		
		JLabel lblItemName = new JLabel("Item Name");
		lblItemName.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		lblItemName.setBounds(100, 122, 149, 36);
		getContentPane().add(lblItemName);
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		lblPrice.setBounds(154, 203, 108, 29);
		getContentPane().add(lblPrice);
		
		text_ItemName = new JTextField();
		text_ItemName.setBounds(259, 130, 200, 29);
		getContentPane().add(text_ItemName);
		text_ItemName.setColumns(10);
		
		text_Price = new JTextField();
		text_Price.setBounds(259, 207, 200, 29);
		getContentPane().add(text_Price);
		text_Price.setColumns(10);
		
		JButton btnA = new JButton("Add");
		btnA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query="insert into permanent_item (item_name,price) values (?,?)";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,text_ItemName.getText());
					pst.setString(2,text_Price.getText());
					pst.execute();
					text_ItemName.setText("");
					text_Price.setText("");
					JOptionPane.showMessageDialog(null,"data saved");
					
					pst.close();
				
					//fillComboBox();
					//rs.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		btnA.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		btnA.setBounds(95, 321, 108, 29);
		getContentPane().add(btnA);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try {
					String query="update permanent_item set item_name='"+text_ItemName.getText()+"' ,price='"+text_Price.getText()+"' where item_name='"+text_ItemName.getText()+"'";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.execute();
					text_ItemName.setText("");
					text_Price.setText("");
					JOptionPane.showMessageDialog(null,"data updated");
					pst.close();
					
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		});
		btnUpdate.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		btnUpdate.setBounds(95, 393, 108, 29);
		getContentPane().add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query="delete from permanent_item where item_name='"+text_ItemName.getText()+"'";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.execute();
					text_ItemName.setText("");
					text_Price.setText("");
					JOptionPane.showMessageDialog(null,"data deleted");
					pst.close();
					
					
					
				} catch (Exception e3) {
					e3.printStackTrace();
				}
			}
		});
		btnDelete.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		btnDelete.setBounds(95, 466, 108, 29);
		getContentPane().add(btnDelete);
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query="select * from permanent_item where item_name=?";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,(String)comboBox.getSelectedItem());
					ResultSet rs=pst.executeQuery();
					while(rs.next())
					{
						text_ItemName.setText(rs.getString("item_name"));
						text_Price.setText(rs.getString("price"));
					}
					//pst.execute();
					pst.close();
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		comboBox.setBounds(301, 316, 171, 29);
		getContentPane().add(comboBox);
		fillComboBox();

	}
}
