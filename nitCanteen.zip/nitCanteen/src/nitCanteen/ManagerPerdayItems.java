package nitCanteen;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JInternalFrame;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ManagerPerdayItems extends JInternalFrame {
	Connection connection=null;
	private JTextField text_Name;
	private JTextField text_Quantity;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManagerPerdayItems frame = new ManagerPerdayItems();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public void fillComboBox()
	{
		try {
			String query="select * from permanent_item";
			PreparedStatement pst=connection.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			comboBox.addItem("Choose!!!!!");
			while(rs.next())
			{
				comboBox.addItem(rs.getString("item_name"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 */
	public ManagerPerdayItems() {
		connection=sqliteconnection.dbConnector();
		setTitle("Manager Perday Items");
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		//setBounds(100, 100, 450, 300);
		setBounds(350, 33, 612, 661);
		getContentPane().setLayout(null);
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query="select * from permanent_item where item_name=?";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,(String)comboBox.getSelectedItem());
					ResultSet rs=pst.executeQuery();
					while(rs.next())
					{
						text_Name.setText(rs.getString("item_name"));
						//text_Price.setText(rs.getString("price"));
					}
					//pst.execute();
					pst.close();
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		comboBox.setBounds(210, 95, 169, 30);
		getContentPane().add(comboBox);
		
		JLabel lblItemName = new JLabel("Item Name :");
		lblItemName.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblItemName.setBounds(99, 199, 107, 30);
		getContentPane().add(lblItemName);
		
		JLabel lblQuantity = new JLabel("Quantity :");
		lblQuantity.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblQuantity.setBounds(99, 267, 91, 30);
		getContentPane().add(lblQuantity);
		
		text_Name = new JTextField();
		text_Name.setBounds(216, 199, 178, 27);
		getContentPane().add(text_Name);
		text_Name.setColumns(10);
		
		text_Quantity = new JTextField();
		text_Quantity.setBounds(216, 267, 178, 27);
		getContentPane().add(text_Quantity);
		text_Quantity.setColumns(10);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					String query="insert into perday_item (item_name,perday_quantity) values (?,?)";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,text_Name.getText());
					pst.setString(2,text_Quantity.getText());
					pst.execute();
					text_Name.setText("");
					text_Quantity.setText("");
					JOptionPane.showMessageDialog(null,"data saved");
					
					pst.close();
				
					//fillComboBox();
					//rs.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		btnAdd.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnAdd.setBounds(81, 418, 107, 30);
		getContentPane().add(btnAdd);
		
		JButton btnNewButton = new JButton("Update");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query="update perday_item set item_name='"+text_Name.getText()+"' ,perday_quantity='"+text_Quantity.getText()+"' where item_name='"+text_Name.getText()+"'";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.execute();
					text_Name.setText("");
					text_Quantity.setText("");
					JOptionPane.showMessageDialog(null,"data updated");
					pst.close();
					
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
				
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton.setBounds(254, 418, 99, 30);
		getContentPane().add(btnNewButton);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query="delete from perday_item where item_name='"+text_Name.getText()+"'";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.execute();
					text_Name.setText("");
					text_Quantity.setText("");
					JOptionPane.showMessageDialog(null,"data deleted");
					pst.close();
					
					
					
				} catch (Exception e3) {
					e3.printStackTrace();
				}
			}
		});
		btnDelete.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnDelete.setBounds(430, 418, 99, 30);
		getContentPane().add(btnDelete);
		fillComboBox();

	}

}
