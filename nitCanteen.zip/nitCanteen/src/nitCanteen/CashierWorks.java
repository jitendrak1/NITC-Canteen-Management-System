package nitCanteen;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;

import java.awt.Font;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JDesktopPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.JSeparator;

public class CashierWorks extends JFrame 
{
	private JPanel contentPane;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					CashierWorks frame = new CashierWorks();
					frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CashierWorks() 
	{
				
		setTitle("Cashier Works");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//setBounds(100, 100, 678, 453);
		setBounds(0, 0, 1370, 730);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.setBounds(0, 0, 1354, 31);
		contentPane.add(menuBar);
		
		JMenu mnNewMenu = new JMenu("File");
		mnNewMenu.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(mnNewMenu);
		
		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBounds(1353, 30, -1351, 662);
		contentPane.add(desktopPane);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("New Order");
		mntmNewMenuItem.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				NewOrder new_order=new NewOrder();
				contentPane.getParent().add(new_order);
				new_order.setVisible(true);
			}
		});
		mntmNewMenuItem.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnNewMenu.add(mntmNewMenuItem);
		
		JSeparator separator = new JSeparator();
		mnNewMenu.add(separator);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(JFrame.EXIT_ON_CLOSE);
			}
		});
		mntmExit.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnNewMenu.add(mntmExit);
		
		JMenu mnEmployee = new JMenu("Employee");
		mnEmployee.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(mnEmployee);
		
		JMenuItem mntmAttendance = new JMenuItem("Attendance");
		mntmAttendance.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				CashierAttendance att=new CashierAttendance();
				contentPane.getParent().add(att);
				att.setVisible(true);
			}
		});
		mntmAttendance.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnEmployee.add(mntmAttendance);
		
		JMenu mnTurnover = new JMenu("Turnover");
		mnTurnover.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(mnTurnover);
		
		JMenuItem mntmShowTurnover = new JMenuItem("Show Turnover");
		mntmShowTurnover.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				CashierShowTurnover turnover=new CashierShowTurnover();
				contentPane.getParent().add(turnover);
				turnover.setVisible(true);
			}
		});
		mntmShowTurnover.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnTurnover.add(mntmShowTurnover);
		
		JMenu mnItem = new JMenu("Item");
		mnItem.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(mnItem);
		
		JMenuItem mntmPerdayItems = new JMenuItem("Perday Items");
		mntmPerdayItems.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				CashierPerdayItems items=new CashierPerdayItems();
				contentPane.getParent().add(items);
				items.setVisible(true);
			}
		});
		mntmPerdayItems.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnItem.add(mntmPerdayItems);
		
		JMenuItem mntmPermanentItems = new JMenuItem("Permanent Items");
		mntmPermanentItems.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				CashierPermanentItems items=new CashierPermanentItems();
				contentPane.getParent().add(items);
				items.setVisible(true);
			}
		});
		mntmPermanentItems.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnItem.add(mntmPermanentItems);
		
		JMenu mnExpenditure = new JMenu("Expenditure");
		mnExpenditure.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(mnExpenditure);
		
		JMenuItem mntmUpdate = new JMenuItem("Update");
		mntmUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CashierExpenditureUpdate update=new CashierExpenditureUpdate();
				contentPane.getParent().add(update);
				update.setVisible(true);
			}
		});
		mntmUpdate.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnExpenditure.add(mntmUpdate);
		
		JMenuItem mntmTotalExpenditure = new JMenuItem("Total Expenditure");
		mntmTotalExpenditure.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				CashierTotalExpenditure total=new CashierTotalExpenditure();
				contentPane.getParent().add(total);
				total.setVisible(true);
			}
		});
		mntmTotalExpenditure.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnExpenditure.add(mntmTotalExpenditure);
				
	}
}
