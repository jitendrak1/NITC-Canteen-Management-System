package nitCanteen;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JButton;

import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JScrollPane;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TotalExpenditure extends JInternalFrame {
	private JTable table;
	Connection connection=null;
	private static JLabel lbltotal;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TotalExpenditure frame = new TotalExpenditure();
					frame.setVisible(true);
					 lbltotal = new JLabel("");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TotalExpenditure() {
		connection=sqliteconnection.dbConnector();
		setTitle("Total Expenditure");
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		//setBounds(100, 100, 450, 300);
		setBounds(350, 33, 612, 661);
		getContentPane().setLayout(null);
		
		JLabel lbltotal = new JLabel("");
		lbltotal.setBounds(324, 528, 104, 32);
		getContentPane().add(lbltotal);

		
		JButton btnNewButton = new JButton("All Expenditure");
		btnNewButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				try
				{
					String query="select * from expenditure";
					PreparedStatement pst=connection.prepareStatement(query);
					ResultSet rs=pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rs));
					

				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 23));
		btnNewButton.setBounds(195, 27, 216, 42);
		getContentPane().add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(51, 120, 519, 350);
		getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnTotalExpenditure = new JButton("Total Expenditure");
		btnTotalExpenditure.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0)
			{
				try 
				{
					int totall=0;
					String query="select total_price from expenditure";
					PreparedStatement pst=connection.prepareStatement(query);
					
					ResultSet rs=pst.executeQuery();
					while(rs.next())
					{
						int s=Integer.parseInt(rs.getString("total_price"));
					    totall=totall+s;
					    lbltotal.setText(""+totall);
					    
					}
					//pst.execute();
					pst.close();
					
				} 
				catch (Exception e1)
				{
					e1.printStackTrace();
				}
			}
		});
		btnTotalExpenditure.setFont(new Font("Times New Roman", Font.PLAIN, 23));
		btnTotalExpenditure.setBounds(75, 528, 200, 42);
		getContentPane().add(btnTotalExpenditure);
		
	    
		
		
		
		lbltotal.setBounds(324, 528, 104, 32);
		getContentPane().add(lbltotal);

	}
}
