package nitCanteen;

import java.awt.EventQueue;
import java.security.acl.Group;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ButtonGroup;
import javax.swing.JInternalFrame;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JRadioButton;
import javax.swing.JPanel;

public class UsernameAndPassword extends JInternalFrame {
	Connection connection=null;
	private JTextField text_Username;
	private JPasswordField passwordField;
	private JComboBox comboBox;
	private JPasswordField NewpasswordField;
	private JRadioButton rdbtnDelete;
	private JRadioButton rdbtnUpdate;
	private JLabel lblSelectUserName;
	private JButton btnDelete;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UsernameAndPassword frame = new UsernameAndPassword();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void fillComboBox()
	{
		try 
		{
			String query="select * from login";
			PreparedStatement pst=connection.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			comboBox.addItem("Choose!!!!!");
			while(rs.next())
			{
				
				comboBox.addItem(rs.getString("uname"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 */
	public UsernameAndPassword() 
	{
		connection=sqliteconnection.dbConnector();
		setTitle("Username And Password");
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		//setBounds(100, 100, 450, 300);
		setBounds(350, 33, 612, 661);
		getContentPane().setLayout(null);
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				try 
				{
					String query="select * from login where uname=?";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,(String)comboBox.getSelectedItem());
					ResultSet rs=pst.executeQuery();
					while(rs.next())
					{
						text_Username.setText(rs.getString("uname"));
						passwordField.setText(rs.getString("password"));
					}
					//pst.execute();
					pst.close();
					
				} 
				catch (Exception e1)
				{
					e1.printStackTrace();
				}
			}
		});
		comboBox.setBounds(403, 67, 169, 31);
		getContentPane().add(comboBox);
		
		JLabel lblUsername = new JLabel("UserName");
		lblUsername.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblUsername.setBounds(39, 211, 107, 24);
		getContentPane().add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblPassword.setBounds(39, 280, 96, 24);
		getContentPane().add(lblPassword);
		
		text_Username = new JTextField();
		text_Username.setBounds(194, 204, 200, 31);
		getContentPane().add(text_Username);
		text_Username.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(194, 275, 200, 29);
		getContentPane().add(passwordField);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					
					String query="update login set uname='"+text_Username.getText()+"' ,password='"+NewpasswordField.getText()+"' where uname='"+text_Username.getText()+"'";
					String query1="update cashierreg set name='"+text_Username.getText()+"' ,password='"+NewpasswordField.getText()+"' where name='"+text_Username.getText()+"'";
					text_Username.setText("");
					
					NewpasswordField.setText("");
					passwordField.setText("");
					PreparedStatement pst=connection.prepareStatement(query);
					PreparedStatement pst1=connection.prepareStatement(query1);
					pst.execute();
					JOptionPane.showMessageDialog(null,"data updated");
					pst.close();
					
					pst1.execute();
					JOptionPane.showMessageDialog(null,"data updated");
					pst1.close();
					
					
				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();
				}
			}
		});
		btnUpdate.setFont(new Font("Times New Roman", Font.PLAIN, 26));
		btnUpdate.setBounds(300, 442, 153, 39);
		getContentPane().add(btnUpdate);
		btnUpdate.setVisible(false);
		
		JLabel lblNewLabel = new JLabel("New Password");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel.setBounds(39, 337, 121, 24);
		getContentPane().add(lblNewLabel);
		lblNewLabel.setVisible(false);
		
		NewpasswordField = new JPasswordField();
		NewpasswordField.setBounds(194, 337, 200, 25);
		getContentPane().add(NewpasswordField);
		NewpasswordField.setVisible(false);
				
		rdbtnDelete = new JRadioButton("Delete");
		rdbtnDelete.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0)
			{
				btnDelete.setVisible(true);
				lblNewLabel.setVisible(false);
				btnUpdate.setVisible(false);
				NewpasswordField.setVisible(false);
				
			}
		});
		rdbtnDelete.setFont(new Font("Times New Roman", Font.BOLD, 18));
		rdbtnDelete.setBounds(42, 20, 79, 31);
		rdbtnDelete.setSelected(false);
		getContentPane().add(rdbtnDelete);
		
		rdbtnUpdate = new JRadioButton("Update");
		rdbtnUpdate.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				btnDelete.setVisible(false);
				lblNewLabel.setVisible(true);
				btnUpdate.setVisible(true);
				NewpasswordField.setVisible(true);
			}
		});
		rdbtnUpdate.setFont(new Font("Times New Roman", Font.BOLD, 18));
		rdbtnUpdate.setBounds(157, 22, 96, 29);
		rdbtnUpdate.setSelected(false);
		getContentPane().add(rdbtnUpdate);
		
		ButtonGroup g=new ButtonGroup();
		g.add(rdbtnDelete);
		g.add(rdbtnUpdate);
		
		lblSelectUserName = new JLabel("Select User Name   :");
		lblSelectUserName.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblSelectUserName.setBounds(219, 65, 169, 31);
		getContentPane().add(lblSelectUserName);
		
		btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				try {
					String query="delete from login where uname='"+text_Username.getText()+"'";
					String query1="delete from cashierreg where name='"+text_Username.getText()+"'";
					String query2="delete from attendance where name='"+text_Username.getText()+"'";
					text_Username.setText("");
					//NewpasswordField.setText("");
					passwordField.setText("");
					PreparedStatement pst=connection.prepareStatement(query);
					PreparedStatement pst1=connection.prepareStatement(query1);
					PreparedStatement pst2=connection.prepareStatement(query2);
					pst.execute();
					JOptionPane.showMessageDialog(null,"data deleted from login");
					pst.close();
					pst1.execute();
					JOptionPane.showMessageDialog(null,"data deleted from cashier");
					pst1.close();
					pst2.execute();
					JOptionPane.showMessageDialog(null,"data deleted from attendance");
					pst2.close();
					
					
				} catch (Exception e3) {
					e3.printStackTrace();
				}
			}
		});
		btnDelete.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		btnDelete.setBounds(106, 442, 147, 39);
		getContentPane().add(btnDelete);
		btnDelete.setVisible(false);
		fillComboBox();

	}
}
