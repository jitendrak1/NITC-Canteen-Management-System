package nitCanteen;

import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.Font;

import javax.swing.JPasswordField;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.SystemColor;

public class Login
{
	Connection connection=null;
	private JFrame frame;
	private JTextField txtEnterTheUser;
	private JPasswordField passwordField;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					Login window = new Login();
					window.frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() 
	{
		initialize();
		connection=sqliteconnection.dbConnector();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() 
	{
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setForeground(Color.PINK);
		frame.setBounds(100, 100, 693, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setToolTipText("");
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Login ", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLACK));
		panel.setBounds(220, 77, 384, 253);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblUserName = new JLabel("User Name    :");
		lblUserName.setBounds(30, 46, 121, 24);
		panel.add(lblUserName);
		lblUserName.setFont(new Font("Times New Roman", Font.BOLD, 20));
		
		JLabel lblPassword = new JLabel("Password       :");
		lblPassword.setBounds(30, 93, 126, 33);
		panel.add(lblPassword);
		lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 20));
		
		txtEnterTheUser = new JTextField();
		txtEnterTheUser.setBackground(Color.LIGHT_GRAY);
		txtEnterTheUser.setBounds(180, 46, 172, 24);
		panel.add(txtEnterTheUser);
		txtEnterTheUser.setFont(new Font("Times New Roman", Font.BOLD, 20));
		txtEnterTheUser.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBackground(Color.LIGHT_GRAY);
		passwordField.setBounds(180, 97, 172, 24);
		panel.add(passwordField);
		passwordField.setFont(new Font("Times New Roman", Font.BOLD, 20));
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBackground(Color.LIGHT_GRAY);
		comboBox.setFont(new Font("Times New Roman", Font.BOLD, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Manager", "Cashier"}));
		comboBox.setBounds(129, 137, 111, 33);
		panel.add(comboBox);
		
		JButton btnLogin = new JButton("LogIn");
		btnLogin.setBackground(Color.LIGHT_GRAY);
		btnLogin.setForeground(Color.BLACK);
		Image img1 = new ImageIcon(this.getClass().getResource("/Ok-icon.png")).getImage();
		btnLogin.setIcon(new ImageIcon(img1));
		/*
		 * Check the login user valid yes or not // Code of login button
		 */
		btnLogin.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				try
				{
					String query="select * from login where uname=? and password=? and type=?";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, txtEnterTheUser.getText());
					pst.setString(2,passwordField.getText());
					pst.setString(3,(String)comboBox.getSelectedItem());
					ResultSet rs=pst.executeQuery();
										
					int count=0;
					while(rs.next())
					{
						count++;
					}
					if(count==1)
					{
						JOptionPane.showMessageDialog(null,"Login successfully........");
						if("Manager"==(String)comboBox.getSelectedItem())
						{
							frame.dispose();
							ManagerWorks mang = new ManagerWorks();
							mang.setVisible(true);
						}
						else if("Cashier"==(String)comboBox.getSelectedItem())
						{
							frame.dispose();
							CashierWorks cash = new CashierWorks();
							cash.setVisible(true);
						}
					}
					else
					{
						JOptionPane.showMessageDialog(null,"User name and password is wrong");
					}
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null,ex);
				}
			}
		});
		
		btnLogin.setBounds(129, 197, 121, 33);
		panel.add(btnLogin);
		btnLogin.setFont(new Font("Times New Roman", Font.BOLD, 20));
		
		JLabel lblNewLabel = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/login_image.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(31, 97, 179, 213);
		frame.getContentPane().add(lblNewLabel);
				
	}
}
