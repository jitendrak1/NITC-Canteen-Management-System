package nitCanteen;

import java.awt.EventQueue;
import java.sql.Connection;

import javax.swing.JInternalFrame;
import javax.swing.JRadioButton;

import java.awt.Font;

import javax.swing.ButtonGroup;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSlider;

public class ManagerShowTurnover extends JInternalFrame 
{
	Connection connection=null;
	private JTextField text_To;
	private JTextField text_From;
	private JTable table;
	private JLabel lblTo;
	private JLabel lblFrom;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					ManagerShowTurnover frame = new ManagerShowTurnover();
					frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManagerShowTurnover() 
	{
		setTitle("Manager Show Turnover");
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		connection=sqliteconnection.dbConnector();
		//setBounds(100, 100, 450, 300);
		setBounds(350, 33, 612, 661);
		getContentPane().setLayout(null);
		
				
		text_To = new JTextField();
		text_To.setBounds(177, 142, 113, 20);
		getContentPane().add(text_To);
		text_To.setColumns(10);
		
		
		text_From = new JTextField();
		text_From.setBounds(355, 142, 113, 20);
		getContentPane().add(text_From);
		text_From.setColumns(10);
		
		
		lblTo = new JLabel("TO:");
		lblTo.setFont(new Font("Times New Roman", Font.BOLD, 13));
		lblTo.setBounds(135, 145, 32, 14);
		getContentPane().add(lblTo);
	
		
		lblFrom = new JLabel("From:");
		lblFrom.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblFrom.setBounds(307, 145, 48, 14);
		getContentPane().add(lblFrom);
		
		
		JButton btnNewButton = new JButton("Show");
		btnNewButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				String to_date=text_To.getText();
				String from_date=text_From.getText();
				int total_turnover=0;
				
				
				
				//System.out.println("To date:"+to_date+" \tfrom date :"+from_date);
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 23));
		btnNewButton.setBounds(235, 226, 126, 31);
		getContentPane().add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(37, 287, 518, 309);
		getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);

	}
}
