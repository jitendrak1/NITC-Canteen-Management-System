package nitCanteen;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ButtonGroup;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTable;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.CompoundBorder;

import net.proteanit.sql.DbUtils;

public class Attendance extends JInternalFrame {
	Connection connection=null;
	private JComboBox comboBox;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Attendance frame = new Attendance();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void fillComboBox()
	{
		try 
		{
			String query="select * from attendance";
			PreparedStatement pst=connection.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			comboBox.addItem("Choose!!!!!");
			while(rs.next())
			{				
				comboBox.addItem(rs.getString("name"));
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 */
	public Attendance() 
	{
		connection=sqliteconnection.dbConnector();
		setTitle("Attendance");
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		//setBounds(100, 100, 450, 300);
		setBounds(300, 33, 812, 661);
		getContentPane().setLayout(null);
		
		JRadioButton rdbtnPresent = new JRadioButton("Present");
		rdbtnPresent.setBounds(161, 192, 106, 40);
		rdbtnPresent.setFont(new Font("Times New Roman", Font.BOLD, 20));
		getContentPane().add(rdbtnPresent);
		
		JRadioButton rdbtnAbsent = new JRadioButton("Absent");
		rdbtnAbsent.setBounds(161, 271, 86, 45);
		rdbtnAbsent.setFont(new Font("Times New Roman", Font.BOLD, 19));
		getContentPane().add(rdbtnAbsent);
				
		ButtonGroup g=new ButtonGroup();
		g.add(rdbtnPresent);
		g.add(rdbtnAbsent);
		
		/*if(rdbtnAbsent.isSelected())
		{	
			String s=;
			int count=Integer.parseInt(s);
		}*/
		
		
		comboBox = new JComboBox();
		comboBox.setBounds(126, 113, 141, 33);
		getContentPane().add(comboBox);
		fillComboBox();
		
		JButton btnAttendance = new JButton("Attendance");
		btnAttendance.setBounds(140, 382, 130, 33);
		btnAttendance.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				//System.out.println(comboBox.getSelectedItem());
				//System.out.println(rdbtnPresent.isSelected());
				try 
				{
					
					String query="select name from attendance where name=?";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1,(String)comboBox.getSelectedItem());
					ResultSet rs=pst.executeQuery();
					if(rdbtnPresent.isSelected())
					{
						String query11="select total_attendance from attendance where name='"+(String)comboBox.getSelectedItem()+"'";
						PreparedStatement pst11=connection.prepareStatement(query11);
						
						ResultSet rs11=pst11.executeQuery();
						
						int s=Integer.parseInt(rs11.getString("total_attendance"));
						
						s=s+1;
						String total=String.valueOf(s);
						//System.out.println(" new total :"+total);
						String q1="update attendance set total_attendance='"+total+"' where name='"+(String)comboBox.getSelectedItem()+"'";
						PreparedStatement pst1=connection.prepareStatement(q1);
						
						pst1.execute();
						JOptionPane.showMessageDialog(null,"data updated");
						pst1.close();
						
					}
					
					String query22="select * from attendance";
					PreparedStatement pst22=connection.prepareStatement(query22);
					ResultSet rs22=pst22.executeQuery();
					
					table.setModel(DbUtils.resultSetToTableModel(rs22));
					
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
				
				
			}
		});
		btnAttendance.setFont(new Font("Times New Roman", Font.BOLD, 20));
		getContentPane().add(btnAttendance);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(33, 76, 359, 439);
		getContentPane().add(scrollPane_2);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(429, 79, 357, 436);
		getContentPane().add(scrollPane_1);
		
		table = new JTable();
		scrollPane_1.setViewportView(table);
		
		

	}
}
