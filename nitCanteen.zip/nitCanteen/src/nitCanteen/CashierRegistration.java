package nitCanteen;

//import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.EventQueue;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

//import mainCanteen.sqliteconnection;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class CashierRegistration extends JInternalFrame
{
	Connection connection=null;
	private JTextField text_cid;
	private JTextField text_AdharCardNO;
	private JTextField text_Name;
	private JTextField text_Fname;
	private JTextField text_DOB;
	private JTextField text_Address;
	private JTextField text_Mobile;
	private JTextField text_PerDayWages;
	private JPasswordField passwordField;
	private JTextField txtCashier;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					CashierRegistration frame = new CashierRegistration();
					frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CashierRegistration() 
	{
		connection=sqliteconnection.dbConnector();
		getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 11));
		setTitle("Cashier Registration");
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		//setBounds(100, 100, 648, 456);
		setBounds(350, 33, 612, 661);
		getContentPane().setLayout(null);
		
		JLabel lblCashierRegist = new JLabel("\t\t\t\t\t\t\t\t\t\tCashier Registration ");
		lblCashierRegist.setHorizontalAlignment(SwingConstants.CENTER);
		lblCashierRegist.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 23));
		lblCashierRegist.setBounds(0, 0, 632, 36);
		getContentPane().add(lblCashierRegist);
		
		JLabel lblCashierId = new JLabel("Cashier ID");
		lblCashierId.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblCashierId.setBounds(85, 55, 116, 14);
		getContentPane().add(lblCashierId);
		
		JLabel lblAdharCardNo = new JLabel("Adhar Card NO");
		lblAdharCardNo.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblAdharCardNo.setBounds(85, 86, 105, 14);
		getContentPane().add(lblAdharCardNo);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblName.setBounds(85, 114, 105, 14);
		getContentPane().add(lblName);
		
		JLabel lblFathersName = new JLabel("Father's Name");
		lblFathersName.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblFathersName.setBounds(85, 139, 105, 14);
		getContentPane().add(lblFathersName);
		
		JLabel lblDob = new JLabel("D.O.B");
		lblDob.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblDob.setBounds(85, 167, 93, 14);
		getContentPane().add(lblDob);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblAddress.setBounds(85, 202, 93, 14);
		getContentPane().add(lblAddress);
		
		JLabel lblMobile = new JLabel("Mobile");
		lblMobile.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblMobile.setBounds(83, 239, 70, 14);
		getContentPane().add(lblMobile);
		
		JLabel lblPerDayWages = new JLabel("Per Day Wages");
		lblPerDayWages.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblPerDayWages.setBounds(85, 275, 116, 14);
		getContentPane().add(lblPerDayWages);
		
		JLabel lblNewLabel = new JLabel("Password");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel.setBounds(85, 300, 68, 18);
		getContentPane().add(lblNewLabel);
		
		JLabel lblType = new JLabel("Type");
		lblType.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblType.setBounds(85, 329, 68, 18);
		getContentPane().add(lblType);
		
		text_cid = new JTextField();
		text_cid.setBounds(232, 47, 200, 20);
		getContentPane().add(text_cid);
		text_cid.setColumns(10);
		
		text_AdharCardNO = new JTextField();
		text_AdharCardNO.setBounds(232, 82, 200, 20);
		getContentPane().add(text_AdharCardNO);
		text_AdharCardNO.setColumns(10);
		
		text_Name = new JTextField();
		text_Name.setBounds(232, 108, 200, 20);
		getContentPane().add(text_Name);
		text_Name.setColumns(10);
		
		text_Fname = new JTextField();
		text_Fname.setBounds(232, 138, 200, 18);
		getContentPane().add(text_Fname);
		text_Fname.setColumns(10);
		
		text_DOB = new JTextField();
		text_DOB.setBounds(232, 165, 200, 20);
		getContentPane().add(text_DOB);
		text_DOB.setColumns(10);
		
		text_Address = new JTextField();
		text_Address.setBounds(232, 200, 200, 20);
		getContentPane().add(text_Address);
		text_Address.setColumns(10);
		
		text_Mobile = new JTextField();
		text_Mobile.setBounds(232, 237, 200, 20);
		getContentPane().add(text_Mobile);
		text_Mobile.setColumns(10);
		
		text_PerDayWages = new JTextField();
		text_PerDayWages.setBounds(232, 274, 200, 18);
		getContentPane().add(text_PerDayWages);
		text_PerDayWages.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(232, 300, 200, 18);
		getContentPane().add(passwordField);
		
		txtCashier = new JTextField();
		txtCashier.setText("Cashier");
		txtCashier.setBounds(232, 330, 200, 18);
		getContentPane().add(txtCashier);
		txtCashier.setColumns(10);
		
		JButton btnSignup = new JButton("Add");
		btnSignup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String query="insert into cashierreg (cid,adharno,name,fname,dob,address,mobile,perdaywages,password,type) values (?,?,?,?,?,?,?,?,?,?)";
				String query1="insert into login (EID,uname,password,type) values (?,?,?,?)";
				String query2="insert into attendance (name,perdaywages) values (?,?)";
				try
				{
					PreparedStatement pst=connection.prepareStatement(query);
					PreparedStatement pst1=connection.prepareStatement(query1);
					PreparedStatement pst2=connection.prepareStatement(query2);
					pst.setString(1,text_cid.getText());
					pst.setString(2,text_AdharCardNO.getText());
					pst.setString(3,text_Name.getText());
					pst.setString(4,text_Fname.getText());
					pst.setString(5,text_DOB.getText());
					pst.setString(6,text_Address.getText());
					pst.setString(7,text_Mobile.getText());
					
					pst.setString(8,text_PerDayWages.getText());
					pst.setString(9,passwordField.getText());
					pst.setString(10,txtCashier.getText());
					pst.execute();
					JOptionPane.showMessageDialog(null,"data saved into cashaire table");
					pst.close();
					
					pst1.setString(1,text_cid.getText());
					pst1.setString(2,text_Name.getText());
					pst1.setString(3,passwordField.getText());
					pst1.setString(4,txtCashier.getText());
					pst1.execute();
					JOptionPane.showMessageDialog(null,"data saved into login table");
					pst1.close();
					
					pst2.setString(1,text_Name.getText());
					pst2.setString(2,text_PerDayWages.getText());
					pst2.execute();
					JOptionPane.showMessageDialog(null,"data saved into attendance table");
					pst2.close();

				}
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
			}
		});
		btnSignup.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnSignup.setBounds(112, 374, 105, 23);
		getContentPane().add(btnSignup);
		
		JButton btnCancel = new JButton("Reset");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				text_cid.setText("");
				text_AdharCardNO.setText("");
				text_Name.setText("");
				text_Fname.setText("");
				text_DOB.setText("");
				text_Address.setText("");
				text_Mobile.setText("");
				text_PerDayWages.setText("");
				passwordField.setText("");
				
			}
		});
		btnCancel.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnCancel.setBounds(314, 374, 89, 23);
		getContentPane().add(btnCancel);

	}
}
