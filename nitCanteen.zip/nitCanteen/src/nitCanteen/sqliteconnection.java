package nitCanteen;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JOptionPane;

public class sqliteconnection 
{
	Connection conn=null;
	public static Connection dbConnector()
	{
		try
		{
			 Class.forName("org.sqlite.JDBC");
			 Connection conn=DriverManager.getConnection("jdbc:sqlite:E:\\Project\\JAVA_PROJECT\\nitCanteen\\canteen.sqlite");
		     //JOptionPane.showMessageDialog(null, "sucess");
		     return conn;
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,e);
			return null;
		}
	}

}
