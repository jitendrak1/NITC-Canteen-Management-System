package nitCanteen;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JDesktopPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JSeparator;

public class ManagerWorks extends JFrame 
{
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					ManagerWorks frame = new ManagerWorks();
					frame.setVisible(true);
				} 
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManagerWorks() 
	{
		setTitle("Manager Works");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//setBounds(100, 100, 646, 508);
		setBounds(0, 0, 1370, 730);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 1354, 32);
		contentPane.add(menuBar);
		
		JMenu mnNewEmployee = new JMenu("File");
		mnNewEmployee.setFont(new Font("Times New Roman", Font.BOLD, 14));
		menuBar.add(mnNewEmployee);
		
		JMenu mnNewRegistration = new JMenu("New Registration");
		mnNewRegistration.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnNewEmployee.add(mnNewRegistration);
		
		JMenuItem mntmCashierRegistration = new JMenuItem("Cashier Registration");
		mntmCashierRegistration.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				CashierRegistration c_r=new CashierRegistration();
				contentPane.getParent().add(c_r);
				c_r.setVisible(true);
			}
		});
		mntmCashierRegistration.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnNewRegistration.add(mntmCashierRegistration);
		
		JMenuItem mntmEmployeeRegistration = new JMenuItem("Employee Registration");
		mntmEmployeeRegistration.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EmployeeRegistration e_r=new EmployeeRegistration();
				contentPane.getParent().add(e_r);
				e_r.setVisible(true);
				
			}
		});
		mnNewRegistration.add(mntmEmployeeRegistration);
		
		JMenu mnUpdate = new JMenu("Update");
		mnUpdate.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnNewEmployee.add(mnUpdate);
		
		JMenuItem mntmUsernameAndPassword = new JMenuItem("Username And Password");
		mntmUsernameAndPassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				UsernameAndPassword unameandpass=new UsernameAndPassword();
				contentPane.getParent().add(unameandpass);
				unameandpass.setVisible(true);
			}
		});
		mntmUsernameAndPassword.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		mnUpdate.add(mntmUsernameAndPassword);
		
		JSeparator separator = new JSeparator();
		mnNewEmployee.add(separator);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(JFrame.EXIT_ON_CLOSE);
			}
		});
		mntmExit.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnNewEmployee.add(mntmExit);
		
		JMenu mnEmployee = new JMenu("Employee");
		mnEmployee.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(mnEmployee);
		
		JMenuItem mntmAttendance = new JMenuItem("Attendance");
		mntmAttendance.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0)
			{
		        Attendance atten=new  Attendance();
				contentPane.getParent().add(atten);
				atten.setVisible(true);

			}
		});
		mntmAttendance.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnEmployee.add(mntmAttendance);
		
		JMenuItem mntmPayment = new JMenuItem("Payment");
		mntmPayment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 Payment pay=new  Payment();
					contentPane.getParent().add(pay);
					pay.setVisible(true);
			}
		});
		mntmPayment.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnEmployee.add(mntmPayment);
		
		JMenuItem mntmUpdateAndDelete = new JMenuItem("Update And Delete");
		mntmUpdateAndDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				    UpdateAndDelete update=new  UpdateAndDelete();
					contentPane.getParent().add(update);
					update.setVisible(true);
			}
		});
		mntmUpdateAndDelete.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnEmployee.add(mntmUpdateAndDelete);
		
		JMenu mnTurnover = new JMenu("Turnover");
		mnTurnover.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(mnTurnover);
		
		JMenuItem mntmShowTurnover = new JMenuItem("Show Turnover");
		mntmShowTurnover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

			    ManagerShowTurnover turnover=new  ManagerShowTurnover();
				contentPane.getParent().add(turnover);
				turnover.setVisible(true);
			}
		});
		mntmShowTurnover.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnTurnover.add(mntmShowTurnover);
		
		JMenu mnNewMenu = new JMenu("Items");
		mnNewMenu.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmPerdayItems = new JMenuItem("Perday Items");
		mntmPerdayItems.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 ManagerPerdayItems items=new   ManagerPerdayItems();
					contentPane.getParent().add(items);
					items.setVisible(true);
			}
		});
		mntmPerdayItems.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnNewMenu.add(mntmPerdayItems);
		
		JMenuItem mntmPermanentItems = new JMenuItem("Permanent Items");
		mntmPermanentItems.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0)
			{
				 ManagerPermanetItems items=new    ManagerPermanetItems();
					contentPane.getParent().add(items);
					items.setVisible(true);
			}
		});
		mntmPermanentItems.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnNewMenu.add(mntmPermanentItems);
		
		JMenu mnExpenditure = new JMenu("Expenditure");
		mnExpenditure.setFont(new Font("Times New Roman", Font.BOLD, 15));
		menuBar.add(mnExpenditure);
		
		JMenuItem mntmUpdate = new JMenuItem("Update");
		mntmUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 ExpenditureUpdate exp=new ExpenditureUpdate();
					contentPane.getParent().add(exp);
					exp.setVisible(true);
			}
		});
		mntmUpdate.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnExpenditure.add(mntmUpdate);
		
		JMenuItem mntmTotalExpenditure = new JMenuItem("Total Expenditure");
		mntmTotalExpenditure.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TotalExpenditure exp=new TotalExpenditure();
				contentPane.getParent().add(exp);
				exp.setVisible(true);
			}
		});
		mntmTotalExpenditure.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		mnExpenditure.add(mntmTotalExpenditure);
		
		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBounds(0, 690, 1354, -668);
		contentPane.add(desktopPane);
		
		
	}
}
